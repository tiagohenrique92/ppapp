-- Adminer 4.8.0 MySQL 5.5.5-10.1.31-MariaDB dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `business_users`;
CREATE TABLE `business_users` (
  `id` int(10) unsigned NOT NULL,
  `cnpj` varchar(14) NOT NULL,
  UNIQUE KEY `cnpj` (`cnpj`),
  KEY `id` (`id`),
  CONSTRAINT `business_users_ibfk_1` FOREIGN KEY (`id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `person_users`;
CREATE TABLE `person_users` (
  `id` int(10) unsigned NOT NULL,
  `cpf` varchar(11) NOT NULL,
  UNIQUE KEY `cpf` (`cpf`),
  KEY `id` (`id`),
  CONSTRAINT `person_users_ibfk_1` FOREIGN KEY (`id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `created_at` datetime NOT NULL,
  `amount` decimal(16,2) NOT NULL,
  `id_payer` int(10) unsigned NOT NULL,
  `id_payee` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_payer` (`id_payer`),
  KEY `id_receiver` (`id_payee`),
  CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`id_payer`) REFERENCES `users` (`id`) ON DELETE NO ACTION,
  CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`id_payee`) REFERENCES `users` (`id`) ON DELETE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `wallets`;
CREATE TABLE `wallets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `id_user` int(10) unsigned NOT NULL,
  `balance` decimal(16,2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `wallets_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 2021-03-24 23:58:26
